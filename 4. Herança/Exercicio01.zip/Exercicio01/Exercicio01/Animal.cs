﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio01
{
    abstract class Animal
    {
        protected String Nome { get; set; }

        public abstract void EmitirSom();

        public Animal(String nome)
        {
            Nome = nome;
        }
    }
}
