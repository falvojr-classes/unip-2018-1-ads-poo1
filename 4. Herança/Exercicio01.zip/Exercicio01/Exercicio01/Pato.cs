﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio01
{
    class Pato : Animal
    {
        public Pato(string nome) : base(nome)
        {
        }

        public override void EmitirSom()
        {
            Console.WriteLine(Nome + " fez Quack!");
        }
    }
}
