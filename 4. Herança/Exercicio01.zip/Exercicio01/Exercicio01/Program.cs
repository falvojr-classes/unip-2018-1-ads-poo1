﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio01
{
    class Program
    {
        static void Main(string[] args)
        {
            Gato gato = new Gato("Fumaca");

            Cachorro cao = new Cachorro("Snup");

            Pato pato = new Pato("Alexandre");

            gato.EmitirSom();
            cao.EmitirSom();
            pato.EmitirSom();

            Console.ReadKey();
        }
    }
}
