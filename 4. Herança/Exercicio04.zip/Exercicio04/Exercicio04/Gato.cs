﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio04
{
    class Gato : Animal
    {
        public void EmitirSom()
        {
            
        }
    }
}
