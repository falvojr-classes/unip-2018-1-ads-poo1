﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio02
{
    class Program
    {
        static void Main(string[] args)
        {
            Pessoa pf = new PessoaFisica();
            pf.Nome = "Venilton";

            Pessoa pj = new PessoaJuridica();
            pf.Nome = "UNIP";
        }
    }
}
