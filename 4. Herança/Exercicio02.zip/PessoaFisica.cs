﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio02
{
    class PessoaFisica : Pessoa
    {
        public String Cpf { get; set; }
        public String DataNascimento { get; set; }
    }
}
