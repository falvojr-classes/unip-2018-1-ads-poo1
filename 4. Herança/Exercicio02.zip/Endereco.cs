﻿using System;

namespace Exercicio02
{
    public class Endereco
    {
        public String Cep { get; set; }
        public String Logradouro { get; set; }
        public String Numero { get; set; }
    }
}