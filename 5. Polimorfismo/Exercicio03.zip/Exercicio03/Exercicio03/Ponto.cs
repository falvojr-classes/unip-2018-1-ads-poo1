﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio03
{
    class Ponto
    {
        public void RegistrarEntrada(Funcionario funcionario)
        {
            if(funcionario is Consultor)
            {
                Consultor consultor = funcionario as Consultor;
                Console.Write(consultor.Nome + " (Consultor)");
            }
            else if (funcionario is Gerente)
            {
                Gerente gerente = funcionario as Gerente;
                Console.Write(gerente.Nome + " (Gerente)");
            }
            else
            {
                Vendedor vendedor = funcionario as Vendedor;
                Console.Write(vendedor.Nome + " (Vendedor)");
            }
            String entrada = String.Format(" - Entrada: {0:dd/MM/yy HH:mm:ss}", DateTime.Now);
            Console.WriteLine(entrada);
        }

        public void RegistrarSaida(Funcionario funcionario)
        {
            Console.Write(funcionario.Nome);
            String saida = String.Format(" - Saida: {0:dd/MM/yy HH:mm:ss}", DateTime.Now);
            Console.WriteLine(saida);
        }
    }
}
