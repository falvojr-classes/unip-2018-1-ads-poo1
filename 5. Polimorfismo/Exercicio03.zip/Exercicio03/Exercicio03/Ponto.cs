﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio03
{
    class Ponto
    {
        private static int contador;
        private List<long> entradas = new List<long>();

        public Ponto()
        {
            contador++;
        }

        public void RegistrarEntrada(Funcionario funcionario)
        {
            if(funcionario.Cpf != 0)
            { 
                Imprimir(funcionario, true);
                entradas.Add(funcionario.Cpf);
            } else
            {
                Console.WriteLine("ERRO: CPF invalido!");
            }
        }

        public void RegistrarSaida(Funcionario funcionario)
        {
            if (entradas.Contains(funcionario.Cpf))
            { 
                Imprimir(funcionario, false);
                entradas.Remove(funcionario.Cpf);
            } else
            {
                Console.WriteLine("ERRO: Entrada nao registrada!");
            }
        }

        public static void Imprimir(Funcionario funcionario, bool ehEntrada)
        {
            if (funcionario is Consultor)
            {
                Consultor consultor = funcionario as Consultor;
                Console.Write(consultor.Cpf + " (Consultor)");
            }
            else if (funcionario is Gerente)
            {
                Gerente gerente = funcionario as Gerente;
                Console.Write(gerente.Cpf + " (Gerente)");
            }
            else
            {
                Vendedor vendedor = funcionario as Vendedor;
                Console.Write(vendedor.Cpf + " (Vendedor)");
            }
            String tipo = ehEntrada ? "Entrada" : "Saida";
            String entrada = String.Format(" - {0}: {1:dd/MM/yy HH:mm:ss}", tipo, DateTime.Now);
            Console.WriteLine(entrada);
        }
    }
}
