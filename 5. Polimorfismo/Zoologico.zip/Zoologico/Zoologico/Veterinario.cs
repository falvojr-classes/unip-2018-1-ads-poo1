﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoologico
{
    class Veterinario
    {
        public string Nome { get; set; }
        public string Cnpj { get; set; }

        public void Examinar(Animal animal)
        {
            string msg = String.Format("{0} examinou {1}: ", Nome, animal.Apelido);
            Console.Write(msg);
            animal.EmitirSom();
        }

        public void Examinar(List<Animal> animais)
        {
            foreach (Animal animal in animais)
            {
                Examinar(animal);
            }
        }
    }
}
