﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoologico
{
    class Program
    {
        static void Main(string[] args)
        {
            Zoologico zoo = new Zoologico();
            zoo.RazaoSocial = "Zoo POO";
            zoo.Animais = new List<Animal>();

            Animal leao = new Leao();
            leao.Apelido = "Simba";
            Animal elefanteF = new Elefante();
            elefanteF.Apelido = "Dumba";
            Animal elefanteM = new Elefante();
            elefanteM.Apelido = "Dumbo";
            Animal preguica = new Preguica();
            preguica.Apelido = "Cid";

            zoo.Animais.Add(elefanteF);
            zoo.Animais.Add(elefanteM);
            zoo.Animais.Add(leao);

            Veterinario veterinario = new Veterinario();
            veterinario.Nome = "Agenor";
            veterinario.Examinar(zoo.Animais);
            veterinario.Examinar(preguica);

            Console.ReadKey();
        }
    }
}
