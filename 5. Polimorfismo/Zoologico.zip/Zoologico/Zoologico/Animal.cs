﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoologico
{
    abstract class Animal
    {
        public string Especie { get; set; }
        public string Apelido { get; set; }

        public abstract void EmitirSom();
    }
}
