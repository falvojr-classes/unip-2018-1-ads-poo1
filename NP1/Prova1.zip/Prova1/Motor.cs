﻿using System;

namespace Prova1
{
    public class Motor
    {
        public String Tipo { get; set; }
        public double Potencia { get; set; }
    }
}
