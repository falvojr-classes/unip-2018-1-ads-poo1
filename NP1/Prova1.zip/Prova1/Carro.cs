﻿using System;

namespace Prova1
{
    public class Carro
    {
        public String Cor { get; set; }
        public String Modelo { get; set; }
        public double VelocidadeAtual { get; private set; }
        public double VelocidadeMaxima { get; set; }
        public Motor Motor { get; set; }

        public Carro()
        {

        }

        public Carro(Motor motor)
        {
            Motor = motor;
        }

        public Carro(Motor motor, String modelo)
        {
            Motor = motor;
            Modelo = modelo;
        }

        public void Ligar()
        {
            Console.WriteLine("Carro ligado e pronto para acelerar");
        }

        public void Acelerar(double valor)
        {
            VelocidadeAtual = VelocidadeAtual + valor;
        }

        public void Acelerar()
        {
            Acelerar(10);
        }
    }
}
