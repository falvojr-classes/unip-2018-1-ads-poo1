﻿using System;

namespace Prova1
{
    class Program
    {
        static void Main(string[] args)
        {
            Motor motor1 = new Motor();
            motor1.Tipo = "1.0";
            motor1.Potencia = 90;

            Motor motor2 = new Motor();
            motor2.Tipo = "2.0";
            motor2.Potencia = 250;

            Carro carro1 = new Carro(motor1);
            Carro carro2 = new Carro(motor2);

            carro1.Ligar();
            carro2.Ligar();

            carro1.Acelerar();
            carro2.Acelerar(50);

            double velocidadeCarro1 = carro1.VelocidadeAtual;
            double velocidadeCarro2 = carro2.VelocidadeAtual;

            Console.WriteLine(velocidadeCarro1);
            Console.WriteLine(velocidadeCarro2);

            Console.ReadLine();
        }
    }


}
