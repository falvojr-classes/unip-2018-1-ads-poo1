﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabalho1
{
    class Aluno
    {
        public String Nome { get; set; }
        public String Cpf { get; set; }
        public String DataNascimento { get; set; }
        public Turma Turma { get; }

        public Aluno(Turma turma)
        {
            Turma = turma;
        }
    }
}
