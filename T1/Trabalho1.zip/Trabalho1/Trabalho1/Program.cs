﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabalho1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Steven Spielberg, nascido em 18/12/1946 e portador do CPF 000000000-00, 
            //ocupa o cargo de diretor, com um salário de R$ 6.000,00;
            Funcionario steven = new Funcionario();
            steven.Nome = "Steven Spielberg";
            steven.Cpf = "000000000-00";
            steven.Cargo = "Diretor";
            steven.Salario = 6000.00;

            //Andrew Tanenbaum, nascido em 16/03/1944 e portador do CPF 111111111-11, 
            //é contratado para o cargo de professor, com um salário de R$ 5.000,00;
            Funcionario andrew = new Funcionario();
            andrew.Nome = "Andrew Tanenbaum";
            andrew.Cpf = "111111111-11";
            andrew.Cargo = "Professor";
            andrew.Salario = 5000.00;

            //Criacao da Turma POO2018
            Turma turma = new Turma();
            turma.Sigla = "POO2018";
            turma.Periodo = "Manhã";

            //Alan Turing, nascido em 13/06/1912 e portador do CPF 101010101-10, 
            //se matricula na turma POO2018 no período da manhã;
            Aluno alan = new Aluno(turma);
            alan.Nome = "Alan Turing";
            alan.DataNascimento = "13/06/1912";
            alan.Cpf = "101010101-10";

            //Nicola Tesla, nascido em 10/07/1956 e portador do CPF 33333333333, 
            //se matricula na turma POO2018 no período da manhã;
            Aluno nicola = new Aluno(turma);
            nicola.Nome = "Nicola Tesla";
            nicola.DataNascimento = "10/07/1956";
            nicola.Cpf = "33333333333";

            //Stephen Hawking, nascido em 08/01/1942 e portador do CPF 888888888-88, 
            //se matricula na turma POO2018 no período da manhã.
            Aluno stephen = new Aluno(turma);
            stephen.Nome = "Stephen Hawking";
            stephen.DataNascimento = "08/01/1942";
            stephen.Cpf = "888888888-88";

            Console.ReadKey();
        }
    }
}
