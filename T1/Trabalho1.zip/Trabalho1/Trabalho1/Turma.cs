﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trabalho1
{
    class Turma
    {
        public String Sigla { get; set; }
        public String Periodo { get; set; }
    }
}
